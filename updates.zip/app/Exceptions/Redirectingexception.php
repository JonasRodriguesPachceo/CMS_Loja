<?php 
namespace App\Exceptions;

use Exception;

class Redirectingexception extends Exception {
    public function __construct() {
    }
}
